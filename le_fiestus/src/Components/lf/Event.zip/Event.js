import React from 'react'
import pic from './photos/image.jpg'
import './Event.css'

export default function Event() {
  return (
    <div className='gallery2'>
    <h3>PHOTOGALLERY</h3>
<div id="slider-container" class="slider">
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	<div class="slide">
			<img src={pic} alt=""/>
	</div>
	
</div>


<div class="overlay"></div>
    </div>    
  )
}